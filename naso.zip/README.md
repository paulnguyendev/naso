Dự án Naso
Cấu trúc URL
- Homepage: http://localhost/obn-naso/
- User: http://localhost/obn-naso/user
- Auth: http://localhost/obn-naso/auth
- Admin: http://localhost/obn-naso/admin