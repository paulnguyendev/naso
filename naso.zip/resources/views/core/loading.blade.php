<div class="loading-wrap">
    <div class="loading-inner">
        <div class="bounce-loading">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>

</div>
