<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js?ver=1671524018"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://static.loveitopcdn.com/backend/plugins/ckeditor/ckeditor.js"></script>
<script src="https://static.loveitopcdn.com/backend/dist/js/plugin.js?id=1fc69adbc9342466a0a6"></script>
<script src="https://static.loveitopcdn.com/backend/js/notice.js"></script>
<script src="https://static.loveitopcdn.com/backend/js/wb.form.js?v=1.7.1"></script>
<script src="https://static.loveitopcdn.com/backend/js/wb.js?v=1.5.1"></script>
<script src="https://static.loveitopcdn.com/backend/js/pages/login.js"></script>
<script src="<?php echo e(asset('obn-dashboard/js/core/form.js')); ?>"></script>
<script src="<?php echo e(asset('obn-dashboard/js/core/popup.js')); ?>?v=<?php echo e(time()); ?>"></script>
<script src="<?php echo e(asset('obn-dashboard/js/authen/register.js')); ?>?v=<?php echo e(time()); ?>"></script>
<script src="<?php echo e(asset('obn-dashboard/js/authen/login.js')); ?>?v=<?php echo e(time()); ?>"></script>
<?php /**PATH C:\Xampp\htdocs\naso\resources\views/auth/elements/scripts.blade.php ENDPATH**/ ?>