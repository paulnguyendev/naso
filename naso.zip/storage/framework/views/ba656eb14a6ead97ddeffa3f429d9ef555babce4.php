<select class="form-control" name="parent_id">
    <option value="" selected="selected">
        Không có
    </option>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_id => $category_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($category_id); ?>">
            <?php echo e($category_name); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php /**PATH C:\Xampp\htdocs\naso\resources\views/admin/pages/productCategory/select.blade.php ENDPATH**/ ?>