<?php
    use App\Helpers\Template\Product;
?>

<?php $__env->startSection('navbar_title', $item['title'] ?? '-'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-9">
            <div class="panel panel-flat">
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-5">
                            <img src="<?php echo e($item['thumbnail']); ?>" alt="" class="img-responsive entry-thumbnail">
                            <div class="entry-gallery">

                                <?php
                                    $galleries = Product::getGallery($item_meta['gallery'] ?? '');
                                    
                                ?>
                                <div class="row">
                                    <?php if(count($galleries) > 0): ?>
                                        <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-xs-3">
                                                <div class="gallery-item">
                                                    <a href="<?php echo e($gallery); ?>" data-fancybox="near-gallery"
                                                        data-caption="1">
                                                        <img src="<?php echo e($gallery); ?>" alt=""
                                                            class="img-responsive">
                                                    </a>

                                                </div>

                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>


                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="entry-top">
                                <h1 class="entry-title"><?php echo e($item['title'] ?? '-'); ?></h1>
                                <div class="desc-list">
                                    <div class="desc-item">
                                        <strong>Mã sản phẩm: </strong>
                                        <span><?php echo e($item['code'] ?? '-'); ?></span>
                                    </div>
                                    <div class="desc-item">
                                        <strong>Thương hiệu: </strong>
                                        <span><?php echo e($item_supplier['name'] ?? '-'); ?></span>
                                    </div>
                                </div>
                                <div class="entry-discount">
                                    <p class="entry-price">
                                        <strong><?php echo e(Product::getPriceProduct($item['regular_price'])); ?></strong>
                                    </p>
                                    <div class="discount-list">
                                        <?php echo Product::getDiscount($item['regular_price'], '2'); ?>

                                        <div>
                                            <span>Giảm giá tối đa</span>
                                            <span>:</span>
                                            <span><?php echo e(Product::getPriceOfPercent($item['regular_price'], $item['percent'])); ?></span>
                                        </div>
                                        <div>
                                            <span>Điểm tích lũy</span>
                                            <span>:</span>
                                            <span><?php echo e($item['point'] ?? 0); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="entry-form">
                                    <div class="entry-stock-info">
                                        <label for="">Số lượng</label>
                                        <div class="stock-input-group">
                                            <button class="quantity-btn btnMinus">
                                                <i class="fa fa-minus"></i>
                                            </button>
                                            <span name="quantity-number" class="quantity-number">1</span>
                                            <button class="quantity-btn btnPlus">
                                                <i class="fa fa-plus"></i>
                                            </button>
                                          
                                        </div>
                                        <span>99 sản phẩm có sẵn</span>
                                    </div>

                                </div>
                                <div class="entry-buttons">
                                    <a href="<?php echo e(route('cart/add', ['id' => $item['id']])); ?>" class="btn btn-primary"
                                        id="btnAddCart" data-url = "<?php echo e(route('cart/add', ['id' => $item['id']])); ?>">Thêm vào giỏ</a>
                                    <a href="#" class="btn btn-info">Mua ngay</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <h2>CHI TIẾT SẢN PHẨM</h2>
                            <div class="entry-content">
                                <?php echo $item_meta['content'] ?? 'Nội dung đang cập nhật...'; ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="panel panel-flat">
                <div class="panel-body">
                    <div class="entry-supplier">
                        <h4><?php echo e($item_supplier['name'] ?? '-'); ?></h4>
                        <div class="entry-supplier-meta">
                            <p><a href="tel:<?php echo e($item_supplier['phone'] ?? '-'); ?>"><?php echo e($item_supplier['phone'] ?? '-'); ?></a>
                            </p>
                            <p><?php echo e($item_supplier['address'] ?? '-'); ?>

                            </p>

                        </div>
                        <?php if($item_supplier['thumbnail'] && isset($item_supplier['thumbnail'])): ?>
                            <img src="<?php echo e($item_supplier['thumbnail']); ?>" class="supplier-thumbnail img-responsive"
                                alt="">
                        <?php endif; ?>

                    </div>
                </div>
            </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_srcipt'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\naso\resources\views/user/pages/product/detail.blade.php ENDPATH**/ ?>