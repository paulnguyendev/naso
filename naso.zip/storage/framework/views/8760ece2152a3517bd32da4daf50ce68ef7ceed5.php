
<?php $__env->startSection('navbar_title', 'Danh sách sản phẩm'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-flat">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-md-3"></div>
                        <div class="col-md-9">
                            <form action="" method="post">
                                <div class="row">
                                    <div class="col-md-4">
                                        <input type="text" name="keyword" placeholder="Tìm kiếm sản phẩm"
                                            class="form-control">
                                    </div>
                                    <div class="col-md-4">
                                        <select name="cat_id" class="form-control">
                                            <option value="">Chọn danh mục</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_id => $category_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category_id); ?>"><?php echo e($category_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <button class="btn btn-primary btn-block">Tìm kiếm</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="row row-5">
                        <?php if(count($items) > 0): ?>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-2">
                                    <?php echo $__env->make('user.templates.product_item', $item, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="col-md-12">
                                <p>Sản phẩm đang cập nhật...</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_srcipt'); ?>
    <script>
        $('select[name="cat_id"]').select2({
            placeholder: 'Chọn thể loại'
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\naso\resources\views/user/pages/supplier/index.blade.php ENDPATH**/ ?>