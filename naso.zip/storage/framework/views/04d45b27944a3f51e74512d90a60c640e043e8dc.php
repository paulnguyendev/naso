<!DOCTYPE html>
<html lang="vi">
<head>
    <?php echo $__env->make('auth.elements.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="login-container">
    <!-- Main navbar -->
    <div class="navbar navbar-inverse">
        <?php echo $__env->make('auth.elements.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <!-- /main navbar -->
    <!-- Page container -->
    <div class="page-container">
        <!-- Page content -->
        <div class="page-content">
            <!-- Main content -->
            <div class="content-wrapper">
                <!-- Content area -->
                <div class="content">
                    <?php echo $__env->yieldContent('content'); ?>
                    <!-- Simple login form -->
                    
                    <!-- /simple login form -->
                    <!-- Footer -->
                    <div class="footer text-muted text-center">
                        &copy; 2022. Xây dựng bởi <a href="https://obn.marketing/" target="_blank">OBN MARKETING</a>
                    </div>
                    <!-- /footer -->
                </div>
                <!-- /content area -->
            </div>
            <!-- /main content -->
        </div>
        <!-- /page content -->
    </div>
    <!-- /page container -->
    <?php echo $__env->make('core.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('auth.elements.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\Xampp\htdocs\naso\resources\views/auth/auth.blade.php ENDPATH**/ ?>