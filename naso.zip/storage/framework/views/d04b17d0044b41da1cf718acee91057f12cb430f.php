
<?php $__env->startSection('title', 'Đăng Ký Đại Lý / CTV'); ?>
<?php $__env->startSection('content'); ?>
    <form method="POST" autocomplete="off" id="formRegister" data-url="<?php echo e(route('auth/postRegister')); ?>">
        <input type="hidden" name="_token" value="NN2qLcQhx0Cv4lMh5Wl8yaKE7XXEdhqtl2VyI22q">
        <div class="panel panel-body login-form">
            <div class="text-center">
                <h5 class="content-group">ĐĂNG KÝ ĐẠI LÝ/CTV</h5>
            </div>
            <div class="form-group has-feedback">
                <label for="name">Họ tên <span class="text-danger">(*)</span></label>
                <input type="text" id="name" name="name" class="form-control" placeholder="Nhập họ & tên của bạn"
                    autocomplete="false">
            </div>
            <div class="form-group has-feedback">
                <label for="username">Tên đăng nhập <span class="text-danger">(*)</span></label>
                <input type="text" id="username" name="username" class="form-control"
                    placeholder="Nhập tên đăng nhập của bạn" autocomplete="false">
            </div>
            <div class="form-group has-feedback">
                <label for="password">Mật khẩu <span class="text-danger">(*)</span></label>
                <input type="password" id="password" name="password" class="form-control"
                    placeholder="Nhập mật khẩu của bạn" autocomplete="false">
            </div>
            <div class="form-group has-feedback">
                <label for="email">Email <span class="text-danger">(*)</span></label>
                <input type="email" id="email" name="email" class="form-control" placeholder="Nhập email của bạn"
                    autocomplete="false">
            </div>
            <div class="form-group has-feedback">
                <label for="parent_code">Mã giới thiệu </label>
                <input type="text" id="parent_code" name="parent_code" class="form-control"
                    placeholder="Nhập mã giới thiệu của bạn" autocomplete="false">
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary btn-block">Đăng ký
                    <i class="icon-circle-right2 position-right"></i></button>
            </div>
            <div class="form-group login-options text-center">
                <p>Đã có tài khoản? <a href="<?php echo e(route('auth/login')); ?>">Đăng nhập ngay</a></p>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\naso\resources\views/auth/pages/register.blade.php ENDPATH**/ ?>