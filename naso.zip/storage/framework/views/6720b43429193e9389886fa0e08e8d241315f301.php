
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12 col-md-3">
            <div class="panel panel-body panel-body-accent">
                <a class="media no-margin" href="<?php echo e(route('user_order/income')); ?>">
                    <div class="media-left media-middle">
                        <i class="icon-coin-dollar icon-3x text-success-400"></i>
                    </div>
                    <div class="media-body text-right">
                        <h3 class="no-margin text-semibold"><?php echo e($totalIncome); ?></h3>
                        <span class="text-uppercase text-size-mini text-muted">TỔNG THU NHẬP</span>
                    </div>
                </a>
            </div>
        </div>
        <div class="col-sm-12 col-md-3">
            <div class="panel panel-body">
                <a class="media no-margin" href="<?php echo e(route('user_order/customer')); ?>">
                    <div class="media-left media-middle">
                        <i class="icon-price-tag2 icon-3x text-indigo-400"></i>
                    </div>
                    <div class="media-body text-right">
                        <h3 class="no-margin text-semibold">0</h3>
                        <span class="text-uppercase text-size-mini text-muted">SỐ LƯỢNG KHÁCH HÀNG</span>
                    </div>
                </a>
            </div>
        </div>
        <div class="col-sm-12 col-md-3">
            <div class="panel panel-body">
                <a class="media no-margin" href="<?php echo e(route('user_order/index')); ?>">
                    <div class="media-body">
                        <h3 class="no-margin text-semibold"><?php echo e($totalOrder); ?></h3>
                        <span class="text-uppercase text-size-mini text-muted">SỐ ĐƠN HÀNG</span>
                    </div>
                    <div class="media-right media-middle">
                        <i class="icon-cart icon-3x text-danger-400"></i>
                    </div>
                </a>
            </div>
        </div>
        <div class="col-sm-12 col-md-3">
            <div class="panel panel-body">
                <a class="media no-margin" href="<?php echo e(route('user_order/index', ['status' => 'complete'])); ?>">
                    <div class="media-body">
                        <h3 class="no-margin text-semibold"><?php echo e($totalOrderSuccess); ?></h3>
                        <span class="text-uppercase text-size-mini text-muted">ĐƠN HÀNG THÀNH CÔNG</span>
                    </div>
                    <div class="media-right media-middle">
                        <i class="icon-folder3 icon-3x text-blue-400"></i>
                    </div>
                </a>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-6">
            <div class="panel panel-body">
                <div class="dashboard-slide">
                    <div class="dashboard-slide-item">
                        <img src="<?php echo e(asset('obn-dashboard/img/slide-1.png')); ?>" alt="Dashboard slide 1"
                            class="img-responsive">
                    </div>
                    <div class="dashboard-slide-item">
                        <img src="<?php echo e(asset('obn-dashboard/img/slide-1.png')); ?>" alt="Dashboard slide 1"
                            class="img-responsive">
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="panel panel-body">
                <div class="dashboard-slide">
                    <div class="dashboard-slide-item">
                        <img src="<?php echo e(asset('obn-dashboard/img/slide-2.png')); ?>" alt="Dashboard slide 1"
                            class="img-responsive">
                    </div>
                    <div class="dashboard-slide-item">
                        <img src="<?php echo e(asset('obn-dashboard/img/slide-1.png')); ?>" alt="Dashboard slide 1"
                            class="img-responsive">
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="panel panel-flat panel-order-dashboard">
                <div class="panel-heading">
                    <h6 class="panel-title text-uppercase">Đơn hàng mới</h6>
                    <div class="heading-elements">
                        <span class="heading-text"><a href="#">Xem
                                tất cả</a></span>
                    </div>
                </div>
                <table class="table table-xlg datatable-ajax" data-source="<?php echo e(route('user_order/dataList')); ?>"
                    data-destroymulti="<?php echo e(route('user_order/destroy-multi')); ?>">
                    <thead>
                        <tr>
                            <th class="text-center" width="50"><input type="checkbox" bs-type="checkbox" value="all"
                                    id="inputCheckAll"></th>
                            <th>Mã đơn hàng</th>
                            <th>Ngày tạo đơn</th>
                            <th>Đại lý</th>
                            <th>Khách hàng</th>
                            <th>Thanh toán</th>
                            <th>Tổng đơn</th>
                            <th>Trạng thái</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_srcipt'); ?>
    <script>
        $('.dashboard-slide').slick({
            dots: false,
            infinite: true,
            speed: 500,
            prevArrow: '<button class="slick-prev slide-btn"> < </button>',
            nextArrow: '<button class="slick-next slide-btn"> > </button>',
        });
    </script>
    <script type="text/javascript">
        var page_type = 'category';
        var lang_code = 'vi';
        var default_language = 'vi';
        var url_extension = '/';
        var columnDatas = [{
                data: null,
                render: function(data) {
                    return WBDatatables.showSelect(data.id);
                },
                orderable: false,
                searchable: false
            },

            {
                data: null,
                render: function(data) {
                    return WBDatatables.showTitle(data.code, data.route_edit);
                },
                orderable: false,
                searchable: false
            },
            {
                data: null,
                render: function(data) {
                    return (!data.created_at) ? '' : data.created_at;
                },
                orderable: false,
                searchable: false
            },
            {
                data: null,
                render: function(data) {
                    return (!data.user.name) ? '' : data.user.name;
                },
                orderable: false,
                searchable: false
            },
            {
                data: null,
                render: function(data) {
                    return (!data.info_order) ? '' : data.info_order;
                },
                orderable: false,
                searchable: false
            },
            {
                data: null,
                render: function(data) {
                    return (!data.payment) ? '' : data.payment;
                },
                orderable: false,
                searchable: false
            },
            {
                data: null,
                render: function(data) {
                    return (!data.total) ? '' : data.total;
                },
                orderable: false,
                searchable: false
            },
            {
                data: null,
                render: function(data) {
                    return (!data.status) ? '' : data.status;
                },
                orderable: false,
                searchable: false
            },
        ];
        WBDatatables.init('.datatable-ajax', columnDatas, {
            "ordering": false,
            "paging": true
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\naso\resources\views/user/pages/dashboard/index.blade.php ENDPATH**/ ?>