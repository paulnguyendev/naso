
<?php $__env->startSection('navbar_title',"Quản lý danh mục sản phẩm"); ?>
<?php $__env->startSection('navbar-right'); ?>
    <li>
        <a href="#" style="padding:5px 5px">
            <button class="btn bg-info heading-btn" type="button">Tạo thể loại</button>
        </a>
    </li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="panel panel-flat">
        <table class="table table-xlg datatable-ajax" data-source="<?php echo e(url('public/data/product-category.json')); ?>"
            data-destroymulti="https://dainghiagroup.com/admin/product/category/destroy-multi">
            <thead>
                <tr>
                    <th class="text-center" width="50"><input type="checkbox" bs-type="checkbox" value="all"
                            id="inputCheckAll"></th>
                    <th class="text-center" width="100">Hình ảnh</th>
                    <th>Tên</th>
                    <th>Đường dẫn</th>
                    <th width="70px" class="text-center">Sắp xếp</th>
                    <th data-orderable="false" width="100px"></th>
                </tr>
            </thead>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\naso\resources\views/admin/pages/product_category.blade.php ENDPATH**/ ?>