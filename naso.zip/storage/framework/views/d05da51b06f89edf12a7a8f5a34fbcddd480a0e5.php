<?php
    use App\Helpers\Obn;
?>

<?php $__env->startSection('content'); ?>
    <div class="panel panel-body active-form text-center">
        <img src="<?php echo e(Obn::get_logo()); ?>" alt="" class="img-responsive active-logo">
        <p><strong><?php echo $msg; ?></strong></p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\naso\resources\views/auth/pages/active.blade.php ENDPATH**/ ?>