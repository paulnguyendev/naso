<div class="loading-wrap">
    <div class="loading-inner">
        <div class="bounce-loading">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>

</div>
<?php /**PATH C:\Xampp\htdocs\naso\resources\views/core/loading.blade.php ENDPATH**/ ?>