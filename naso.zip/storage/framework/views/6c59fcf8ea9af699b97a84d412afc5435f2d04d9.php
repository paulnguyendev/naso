
<?php $__env->startSection('title','Doanh thu'); ?>
<?php $__env->startSection('navbar_title', 'Doanh thu'); ?>
<?php $__env->startSection('content'); ?>
<div class="panel panel-flat">
    <table class="table table-xlg datatable-ajax" data-source="<?php echo e(route('user_order/dataIncome')); ?>"
        data-destroymulti="<?php echo e(route('user_order/destroy-multi')); ?>">
        <thead>
            <tr>
                <th class="text-center" width="50"><input type="checkbox" bs-type="checkbox" value="all"
                        id="inputCheckAll"></th>
                <th>Mã đơn hàng</th>
                <th>Trạng thái</th>
               
                <th>Tổng đơn hàng</th>
                <th>Hoa hồng</th>
                <th>Điểm tích lũy</th>
            </tr>
        </thead>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_srcipt'); ?>
    <script type="text/javascript">
        var page_type = 'category';
        var lang_code = 'vi';
        var default_language = 'vi';
        var url_extension = '/';
        var columnDatas = [{
                data: null,
                render: function(data) {
                    return WBDatatables.showSelect(data.id);
                },
                orderable: false,
                searchable: false
            },
            {
                data: null,
                render: function(data) {
                    return WBDatatables.showTitle(data.code, data.route_edit );
                },
                orderable: false,
                searchable: false
            },
            {
                data: null,
                render: function(data) {
                    return (!data.show_status) ? '' : data.show_status;
                },
                orderable: false,
                searchable: false
            },
            
            {
                data: null,
                render: function(data) {
                    return (!data.total_point) ? '-' : data.show_order_total;
                },
                orderable: false,
                searchable: false
            },
            {
                data: null,
                render: function(data) {
                    return (!data.show_total_commission) ? '-' : data.show_total_commission;
                },
                orderable: false,
                searchable: false
            },
            {
                data: null,
                render: function(data) {
                    return (!data.total_point) ? '-' : data.total_point;
                },
                orderable: false,
                searchable: false
            },
        ];
        WBDatatables.init('.datatable-ajax', columnDatas, {
            "ordering": false,
            "paging": false
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\naso\resources\views/user/pages/order/income.blade.php ENDPATH**/ ?>