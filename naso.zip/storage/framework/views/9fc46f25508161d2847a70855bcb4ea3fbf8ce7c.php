
<?php $__env->startSection('title','Danh sách đơn hàng'); ?>
<?php $__env->startSection('navbar_title', 'Danh sách đơn hàng'); ?>
<?php $__env->startSection('content'); ?>
<div class="panel panel-flat">
    <table class="table table-xlg datatable-ajax" data-source="<?php echo e(route('user_order/dataList')); ?>"
        data-destroymulti="<?php echo e(route('user_order/destroy-multi')); ?>">
        <thead>
            <tr>
                <th class="text-center" width="50"><input type="checkbox" bs-type="checkbox" value="all"
                        id="inputCheckAll"></th>
                <th>Mã đơn hàng</th>
                <th>Ngày tạo đơn</th>
                <th>Đại lý</th>
                <th>Khách hàng</th>
                <th>Thanh toán</th>
                <th>Giá trị đơn hàng</th>
                <th>Trạng thái</th>
            </tr>
        </thead>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_srcipt'); ?>
    <script type="text/javascript">
        var page_type = 'category';
        var lang_code = 'vi';
        var default_language = 'vi';
        var url_extension = '/';
        var columnDatas = [{
                data: null,
                render: function(data) {
                    return WBDatatables.showSelect(data.id);
                },
                orderable: false,
                searchable: false
            },
           
            {
                data: null,
                render: function(data) {
                    return WBDatatables.showTitle(data.code, data.route_edit );
                },
                orderable: false,
                searchable: false
            },
            {
                data: null,
                render: function(data) {
                    return (!data.created_at) ? '' : data.created_at;
                },
                orderable: false,
                searchable: false
            },
            {
                data: null,
                render: function(data) {
                    return (!data.user.name) ? '' : data.user.name;
                },
                orderable: false,
                searchable: false
            },
            {
                data: null,
                render: function(data) {
                    return (!data.info_order) ? '' : data.info_order;
                },
                orderable: false,
                searchable: false
            },
            {
                data: null,
                render: function(data) {
                    return (!data.payment) ? '' : data.payment;
                },
                orderable: false,
                searchable: false
            },
            {
                data: null,
                render: function(data) {
                    return (!data.total) ? '' : data.total;
                },
                orderable: false,
                searchable: false
            },
            {
                data: null,
                render: function(data) {
                    return (!data.status) ? '' : data.status;
                },
                orderable: false,
                searchable: false
            },
        ];
        WBDatatables.init('.datatable-ajax', columnDatas, {
            "ordering": false,
            "paging": false
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\naso\resources\views/user/pages/order/index.blade.php ENDPATH**/ ?>