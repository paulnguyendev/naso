
<?php $__env->startSection('content'); ?>
    <form id="formLogin" data-url="<?php echo e(route('auth/postLogin')); ?>" data-type="user">
        <div class="panel panel-body login-form">
            <div class="text-center">
                <div class="icon-object border-slate-300 text-slate-300"><i class="icon-reading"></i>
                </div>
                <h5 class="content-group">Đăng nhập hệ thống thành viên</h5>
            </div>
            <div class="form-group has-feedback">
                <label for="username">Tên đăng nhập</label>
                <input type="text" name="username" required class="form-control" placeholder="Tên đăng nhập"
                    value="" id="username">
            </div>
            <div class="form-group has-feedback">
                <label for="password">Mật khẩu</label>
                <input type="password" name="password" required class="form-control" placeholder="Mật khẩu" value="" id="password">
            </div>
            
            <div class="form-group">
                <button type="submit" class="btn btn-primary btn-block">Đăng nhập
                    <i class="icon-circle-right2 position-right"></i></button>
            </div>
            <div class="form-group login-options text-center">
                <p>Chưa có tài khoản? <a href="<?php echo e(route('auth/register')); ?>">Đăng ký ngay</a></p>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\naso\resources\views/auth/pages/login.blade.php ENDPATH**/ ?>