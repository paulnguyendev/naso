<?php
    use App\Helpers\Link\ProductLink;
    use App\Helpers\Template\Product;
    $link = ProductLink::getLinkProductDetail($item['id']);
?>
<div class="product-item">
    <div class="product-thumbnail">
        <a href="<?php echo e($link); ?>"><img class="img-responsive" src="<?php echo e($item['thumbnail']); ?>" alt=""></a>
    </div>
    <div class="product-text">
        <h4 class="product-title">
            <a href="<?php echo e($link); ?>"><?php echo e($item['title'] ?? ''); ?></a>
        </h4>
        <p class="product-price">
            <?php
                $price = $item['regular_price'] ?? 0;
                $price = Product::getPriceProduct($price);
            ?>
            <?php echo e($price); ?>

        </p>
        <div class="product-price-discount">
            <?php echo Product::getDiscount($item['regular_price'] ?? 0); ?>

            <div class="product-price-discount-item">
                <span>Point: </span>
                <div>
                    <span><?php echo e($item['point'] ?? 0); ?></span>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Xampp\htdocs\naso\resources\views/user/templates/product_item.blade.php ENDPATH**/ ?>